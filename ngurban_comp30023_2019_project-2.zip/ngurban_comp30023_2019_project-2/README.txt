COMP30023 2019 project 2
Assignment by Nicholas Gurban, 757235.

This submission zip folder has fewer files than GitLab, but the files that are here are identical to the ones there.
Since the program appends to found_pwds.txt every time it runs with one or fewer arguments, I have included a backup.